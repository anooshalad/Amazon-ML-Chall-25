import os
import re
import gc
import torch
import numpy as np
import pandas as pd
import requests
from torch import nn
from torch.utils.data import Dataset, DataLoader
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from transformers import AutoTokenizer, AutoModel
from torchvision import models, transforms
from PIL import Image
import lightning as L
from lightning.pytorch.callbacks import ModelCheckpoint, EarlyStopping
from tqdm import tqdm

# ---------------- CONFIG ----------------
MODEL_NAME = "google/electra-small-discriminator"
MAX_LEN = 128
LR = 2e-4
EPOCHS = 6
BATCH = 8
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
IMG_DIR = "images"
os.makedirs(IMG_DIR, exist_ok=True)

print(f"Training multimodal model ({MODEL_NAME} + EfficientNetB0) on {DEVICE.upper()}")

# ---------------- DATA LOADING ----------------
train = pd.read_csv("train.csv")
test = pd.read_csv("test.csv")

# Clean text
def clean_text(t):
    if pd.isna(t):
        return ""
    t = re.sub(r"<[^>]+>", " ", t)
    t = re.sub(r"[^a-zA-Z0-9\s]", " ", t)
    return re.sub(r"\s+", " ", t).lower().strip()

for df in [train, test]:
    df["clean_text"] = df["catalog_content"].apply(clean_text)
    df["ipq"] = df["catalog_content"].apply(
        lambda x: int(re.search(r"(\d+)\s*(pack|pcs|piece|pieces|count|qty)", str(x)).group(1))
        if re.search(r"(\d+)\s*(pack|pcs|piece|pieces|count|qty)", str(x))
        else 1
    )
    df["num_words"] = df["clean_text"].str.split().str.len()

# ---------------- IMAGE DOWNLOAD ----------------
def download_image(url, save_path):
    try:
        r = requests.get(url, timeout=5)
        if r.status_code == 200:
            with open(save_path, "wb") as f:
                f.write(r.content)
            return save_path
    except:
        pass
    return None

def ensure_images(df, prefix):
    paths = []
    for i, url in enumerate(tqdm(df["image_link"], desc=f"Downloading {prefix} images")):
        path = os.path.join(IMG_DIR, f"{prefix}_{i}.jpg")
        if not os.path.exists(path):
            saved = download_image(url, path)
            paths.append(saved if saved else None)
        else:
            paths.append(path)
    return paths

train["image_path"] = ensure_images(train, "train")
test["image_path"] = ensure_images(test, "test")

# ---------------- FEATURE EXTRACTION ----------------
tfidf = TfidfVectorizer(max_features=3000, ngram_range=(1, 2))
tfidf_train = tfidf.fit_transform(train["clean_text"]).astype("float32").toarray()
tfidf_test = tfidf.transform(test["clean_text"]).astype("float32").toarray()

scaler = StandardScaler()
train_num = scaler.fit_transform(train[["ipq", "num_words"]])
test_num = scaler.transform(test[["ipq", "num_words"]])

tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)

image_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406],
                         [0.229, 0.224, 0.225])
])

# ---------------- DATASET ----------------
class PriceDataset(Dataset):
    def __init__(self, texts, tfidf, num, img_paths, y=None):
        self.texts, self.tfidf, self.num, self.img_paths, self.y = texts, tfidf, num, img_paths, y
    def __len__(self):
        return len(self.texts)
    def __getitem__(self, i):
        enc = tokenizer(
            self.texts[i], truncation=True, padding="max_length",
            max_length=MAX_LEN, return_tensors="pt"
        )
        item = {k: v.squeeze(0) for k, v in enc.items()}
        item["tfidf"] = torch.tensor(self.tfidf[i], dtype=torch.float)
        item["num"] = torch.tensor(self.num[i], dtype=torch.float)

        # Image
        path = self.img_paths[i]
        if path and os.path.exists(path):
            try:
                image = Image.open(path).convert("RGB")
                image = image_transform(image)
            except:
                image = torch.zeros(3, 224, 224)
        else:
            image = torch.zeros(3, 224, 224)
        item["image"] = image

        if self.y is not None:
            item["labels"] = torch.tensor(self.y[i], dtype=torch.float)
        return item

# ---------------- MODEL ----------------
class TextImageRegressor(nn.Module):
    def __init__(self, dropout=0.3):
        super().__init__()
        # Text encoder
        self.backbone = AutoModel.from_pretrained(MODEL_NAME)
        for p in list(self.backbone.parameters())[:-8]:
            p.requires_grad = False

        # Image encoder
        self.efficient = models.efficientnet_b0(weights=models.EfficientNet_B0_Weights.DEFAULT)
        self.efficient.classifier = nn.Identity()

        h_text = self.backbone.config.hidden_size
        h_img = 1280
        h_tfidf = 3000
        h_num = 2

        self.fc = nn.Sequential(
            nn.Linear(h_text + h_img + h_tfidf + h_num, 1024),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(1024, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, 1)
        )

    def forward(self, input_ids, attention_mask, tfidf, num, image):
        text_out = self.backbone(input_ids=input_ids, attention_mask=attention_mask)
        cls = text_out.last_hidden_state[:, 0, :]
        img_feat = self.efficient(image)
        x = torch.cat([cls, img_feat, tfidf, num], 1)
        return self.fc(x).squeeze(1)

# ---------------- LIGHTNING MODULE ----------------
class PriceLitModel(L.LightningModule):
    def __init__(self):
        super().__init__()
        self.model = TextImageRegressor()
        self.loss_fn = nn.L1Loss()
    def forward(self, batch):
        return self.model(batch["input_ids"], batch["attention_mask"],
                          batch["tfidf"], batch["num"], batch["image"])
    def training_step(self, batch, _):
        y, yhat = batch["labels"], self(batch)
        loss = self.loss_fn(yhat, y)
        self.log("train_loss", loss, prog_bar=True)
        return loss
    def validation_step(self, batch, _):
        y, yhat = batch["labels"], self(batch)
        loss = self.loss_fn(yhat, y)
        smape = 100 * torch.mean(
            2 * torch.abs(yhat - y) / (torch.abs(yhat) + torch.abs(y) + 1e-8)
        )
        self.log_dict({"val_loss": loss, "val_smape": smape}, prog_bar=True)
        return {"val_smape": smape}
    def configure_optimizers(self):
        opt = torch.optim.AdamW(self.parameters(), lr=LR, weight_decay=1e-4)
        sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
        return {"optimizer": opt, "lr_scheduler": sch}

# ---------------- DATA SPLIT ----------------
y_log = np.log1p(train["price"].values)
Xtr, Xv, tfidf_tr, tfidf_v, num_tr, num_v, img_tr, img_v, ytr, yv = train_test_split(
    train["clean_text"], tfidf_train, train_num, train["image_path"], y_log,
    test_size=0.15, random_state=42
)

train_ds = PriceDataset(Xtr.to_numpy(), tfidf_tr, num_tr, img_tr.to_numpy(), ytr)
val_ds = PriceDataset(Xv.to_numpy(), tfidf_v, num_v, img_v.to_numpy(), yv)
train_dl = DataLoader(train_ds, batch_size=BATCH, shuffle=True, num_workers=2)
val_dl = DataLoader(val_ds, batch_size=BATCH, num_workers=2)

# ---------------- TRAINING ----------------
checkpoint_cb = ModelCheckpoint(monitor="val_smape", mode="min", save_top_k=1)
early_stop_cb = EarlyStopping(monitor="val_smape", mode="min", patience=2)
trainer = L.Trainer(
    accelerator="auto",
    devices=1,
    max_epochs=EPOCHS,
    precision=16 if torch.cuda.is_available() else 32,
    log_every_n_steps=10,
    callbacks=[checkpoint_cb, early_stop_cb]
)

print("Starting multimodal training...")
trainer.fit(PriceLitModel(), train_dl, val_dl)
print("Training complete.")

# ---------------- PREDICTION ----------------
best_ckpt = checkpoint_cb.best_model_path
print(f"Best checkpoint: {best_ckpt}")

model = PriceLitModel.load_from_checkpoint(best_ckpt).to(DEVICE).eval()
test_ds = PriceDataset(test["clean_text"].to_numpy(), tfidf_test, test_num, test["image_path"].to_numpy())
test_dl = DataLoader(test_ds, batch_size=BATCH)
preds = []

print("Predicting on test set...")
with torch.no_grad():
    for b in tqdm(test_dl):
        p = model.model(
            b["input_ids"].to(DEVICE),
            b["attention_mask"].to(DEVICE),
            b["tfidf"].to(DEVICE),
            b["num"].to(DEVICE),
            b["image"].to(DEVICE)
        )
        preds.extend(np.expm1(p.cpu().numpy()))

test["price"] = np.clip(preds, 0.01, None)
test[["sample_id", "price"]].to_csv("submission_multimodal.csv", index=False)
print("Saved: submission_multimodal.csv")

torch.cuda.empty_cache()
gc.collect()
